# Running experiment-go on Google Cloud

A hands-on path from the local docker-compose stack to Cloud Run, then to GKE, then to
load testing the result. Every step is a `make` target; every target prints the plain
`gcloud`/`kubectl` command it runs, so you can see what is actually happening.

The order matters: Cloud SQL first (both compute options need it), then Cloud Run
(deployed in two minutes, no cluster to reason about), then GKE (where the interesting
experiments live).

```
                    ┌──────────────────────────┐
   phase 3          │ Cloud Run (serverless)   │──┐
                    │ scale 0..5, unix socket  │  │
                    └──────────────────────────┘  │   ┌────────────────────────┐
                                                  ├──▶│ Cloud SQL Postgres     │
                    ┌──────────────────────────┐  │   │ db-f1-micro, zonal     │
   phase 4/5        │ GKE (2 spot nodes)       │──┘   └────────────────────────┘
                    │ api pods + proxy sidecar │
                    │ HPA 2..10, LB or forward │
                    └──────────────────────────┘
                              ▲
   phase 6                    │ k6: local or as an in-cluster Job
```

## Cost reality check

| Resource | While running | Notes |
| --- | --- | --- |
| Cloud SQL `db-f1-micro`, 10 GB HDD, no backups | ~$0.015/h (~$10/mo) | Shared core, no SLA — fine for experiments, not for production |
| GKE cluster management fee | $0.10/h per cluster | **$74.40/month of free credit per billing account** covers one zonal or Autopilot cluster |
| 2 × `e2-standard-2` **spot** nodes | ~$0.04–0.05/h total | Spot is ~70% cheaper and can be preempted — which is itself a good experiment |
| Network load balancer (`experiment-go-lb`) | ~$0.025/h + traffic | Skip it and use `make k8s-forward` for free |
| Cloud Run | ~$0 idle | Scales to zero; a load test costs cents |
| Artifact Registry | ~$0.10/GB/mo | The image is ~25 MB |

Rough total if you leave everything running: **$0.20–0.25/hour**, dominated by nodes and
the load balancer, with the cluster fee absorbed by the free credit. An evening of
experiments is well under a euro; a forgotten cluster is ~$50/month. Prices change and
vary by region — check the [pricing calculator](https://cloud.google.com/products/calculator)
and set a budget alert before you start:

```bash
gcloud billing budgets create --billing-account=YOUR_BILLING_ID \
  --display-name="experiment-go" --budget-amount=20EUR \
  --threshold-rule=percent=0.5 --threshold-rule=percent=0.9
```

**When you stop for the day: `make teardown-all`.** It deletes the app, Cloud Run
service, cluster and database. Everything here is rebuildable from this repo in ~15
minutes, so treat the cloud side as disposable.

## Phase 0 — prerequisites

```bash
brew install --cask google-cloud-sdk        # gcloud
brew install kubectl k6 cloud-sql-proxy     # kubectl, load tester, local proxy

gcloud auth login
gcloud config set project YOUR_PROJECT_ID   # create one in the console first, with billing on
gcloud auth application-default login       # so the local proxy can authenticate

make gcp-config                             # sanity-check what the targets will use
make gcp-bootstrap                          # enable APIs + create the image repo
```

`REGION` defaults to `europe-north1` (Finland — lowest latency from Tallinn and one of
the cheaper regions). Override anything on the command line or in `.env`:

```bash
make gcp-config REGION=europe-west1
```

Put `SQL_PASSWORD` in `.env` (it reuses `POSTGRES_PASSWORD` if that is set) so you are not
typing it into every command. For anything beyond experiments, keep it in Secret Manager
instead — see the note at the end of phase 3.

> **Apple Silicon:** your Mac builds `arm64` images by default, GKE/Cloud Run nodes are
> `amd64`. `make image-push` uses `docker buildx --platform linux/amd64` for exactly this
> reason. A plain `docker build` + `docker push` gives you pods that crash with
> `exec format error`.

## Phase 1 — Cloud SQL for Postgres

```bash
make sql-create      # instance + database + user (~5 minutes)
make sql-info        # state and the connection name PROJECT:REGION:INSTANCE
```

That creates the cheapest useful shape: `db-f1-micro`, zonal, 10 GB HDD, backups off.

The **connection name** (`PROJECT_ID:REGION:experiment-pg`) is the identifier everything
else uses — not a host and port. Cloud SQL has no public route you should be using
directly; instead the Cloud SQL Auth Proxy (or the connector built into Cloud Run) opens
an IAM-authenticated, TLS-encrypted tunnel and gives you a plain local port. So your app
keeps connecting to `127.0.0.1:5432` with `sslmode=disable` while the transport is
actually authenticated and encrypted.

Run your local app against the cloud database to see it work:

```bash
make sql-proxy                                    # terminal 1: proxy on :5433
DATABASE_URL="postgres://app:$SQL_PASSWORD@localhost:5433/experiment?sslmode=disable" \
  MIGRATE_ON_START=true go run ./cmd/api          # terminal 2
make smoke                                        # terminal 3
```

`make sql-psql` opens psql the same way (it temporarily authorises your IP).

> **The connection budget is the first thing you will hit.** `db-f1-micro` allows roughly
> 25 connections total. `DB_MAX_CONNS × replicas` must stay under that, minus a couple for
> your own psql sessions. The manifests ship `DB_MAX_CONNS=5`, so 10 HPA replicas = 50
> connections = `FATAL: too many connections`. That is a genuinely useful failure to
> trigger on purpose in phase 5.

## Phase 2 — push the image

```bash
make image-push                  # buildx --platform linux/amd64 → Artifact Registry
make gcp-config | grep IMAGE     # the exact tag that was pushed
```

The tag comes from `git describe`, so commit before pushing if you want meaningful tags
(`experiment-go:dev` otherwise). The same image serves three roles: the API server, the
migration tool (`api migrate up`), and the Cloud Run revision.

## Phase 3 — Cloud Run

```bash
make run-deploy      # deploy + attach the Cloud SQL instance
make run-url         # https://experiment-go-xxxxx.a.run.app
make run-smoke       # k6 smoke test against that URL
make run-logs        # structured logs, live
```

What `run-deploy` sets up, and why:

- `--add-cloudsql-instances` mounts a unix socket at `/cloudsql/PROJECT:REGION:INSTANCE`.
  The DSN becomes `postgres://user:pass@/experiment?host=/cloudsql/...` — pgx and
  golang-migrate both take a socket path this way, which is why no code changed.
- `MIGRATE_ON_START=true` is reasonable here: Cloud Run has no Job primitive, and
  golang-migrate's advisory lock makes concurrent revision starts safe.
- `--min-instances=0` means scale to zero — near-free when idle, at the cost of a cold
  start (Go + this image: expect a few hundred ms, plus first-connection setup).
- `--concurrency=80` is requests per instance. Lower it to 1 and watch instance count
  explode during a load test; that contrast is the whole point of the serverless model.

Things worth trying before moving on:

```bash
# cold start, measured
make run-deploy       # after this, wait a few minutes for it to scale to zero
time curl -s $(make -s run-url)/healthz

# how does it behave under load, and how far does it scale?
make loadtest-load BASE_URL=$(make -s run-url) RATE=100 DURATION=2m
```

Then watch instance count and request latency in Cloud Run → Metrics. You will likely see
`readyz` fine but p99 spikes at the start of each new instance — those are cold starts plus
the connection pool warming up.

> Passing the password as an env var is fine for a throwaway experiment, not beyond it.
> The production shape is Secret Manager:
> `gcloud secrets create db-password --data-file=-` then
> `gcloud run deploy ... --set-secrets=POSTGRES_PASSWORD=db-password:latest`, and IAM
> database authentication instead of a password at all.

## Phase 4 — GKE

```bash
make gke-create      # zonal cluster, 2 spot e2-standard-2, autoscaling 1..4 (~5 min)
make gke-bind-sa     # Workload Identity: the pods' ServiceAccount → roles/cloudsql.client
make k8s-deploy      # namespace, secret, config, deployment, services, HPA, PDB
make k8s-migrate     # schema migrations as a Job, then prints its log
make k8s-status
```

Reaching the service:

```bash
make k8s-url         # external IP of the load balancer (a minute or two to appear)
make k8s-forward     # or free: localhost:8080 → the ClusterIP service
```

What is in `deploy/k8s/` and why it looks like that:

| File | Point of interest |
| --- | --- |
| `01-serviceaccount.yaml` | No key files anywhere. `make gke-bind-sa` grants Cloud SQL access to the KSA itself via Workload Identity Federation |
| `02-config.yaml` | `MIGRATE_ON_START=false` here — with N replicas, schema changes should be one explicit step, not a race at boot |
| `03-migrate-job.yaml` | Same image, `args: ["migrate", "up"]`. The proxy runs as a *native* sidecar so the Job can actually complete |
| `04-deployment.yaml` | Proxy as native sidecar (starts first, stops last), `/healthz` for liveness vs `/readyz` for readiness, `preStop: sleep 5`, no CPU limit |
| `05-service.yaml` | ClusterIP for in-cluster clients (k6), plus an optional LoadBalancer |
| `06-hpa.yaml` | CPU at 60% of *request*, 2..10 replicas, shortened scale-up window so you can see it react |
| `07-pdb.yaml` | Keeps one pod alive through node drains and spot preemptions |

Two details that matter more than they look:

**Liveness must not depend on the database.** `/healthz` never touches Postgres, `/readyz`
pings it. If liveness pinged the database, a 30-second Cloud SQL blip would restart every
pod in the cluster simultaneously — turning a brief dependency failure into an outage.
With this split, pods leave the load balancer (not ready) and come back when the database
does.

**`preStop: sleep 5` is what removes 502s from your rollout graphs.** When a pod is
deleted, kubelet starts termination and the endpoints controller removes it from the
Service — concurrently. Without the pause, the load balancer keeps sending requests to a
server that already stopped accepting them. Prove it: run a load test, `kubectl rollout
restart deploy/experiment-go`, and compare error counts with and without that hook.

## Phase 5 — play with the cluster

Run these while a load test is going (`make loadtest-load BASE_URL=... RATE=50 DURATION=10m`)
and keep `make k8s-watch` open in another terminal.

**Rolling update with zero errors.** `make image-push && make k8s-deploy` (or
`kubectl -n experiment-go rollout restart deploy/experiment-go`). With `maxUnavailable: 0`
and the preStop hook, k6's `http_req_failed` should stay at 0.

**Kill a pod.** `kubectl -n experiment-go delete pod <name>` — watch the Deployment
replace it, and watch k6's error count. Then delete two of three at once and see the PDB
and readiness gates do their work.

**Drain a node.** `kubectl drain <node> --ignore-daemonsets --delete-emptydir-data`. Pods
reschedule onto the other node; the PDB stops both replicas going at once. Then
`kubectl uncordon <node>`.

**Autoscale on purpose.** `make loadtest-stress BASE_URL=$(make -s k8s-url) BURN_MS=100
PEAK_RATE=300`. The stress script hits `/api/v1/burn?ms=N`, which spins CPU deliberately
so the HPA has a reason to act — the CRUD endpoints are database-wait-bound and barely
move the CPU graph. Watch: HPA reacts within ~15–30s (its metric window), pods become
ready in a few seconds, and scale-down waits out the 120s stabilisation window.

**Hit the node ceiling.** Scale beyond what two nodes can fit
(`make k8s-scale n=12`) and watch pods sit in `Pending` with
`Insufficient cpu`, then the cluster autoscaler add a node (a minute or two), then the
pods schedule. `kubectl -n experiment-go describe pod <pending-pod>` shows the reason.

**Break the database connection budget.** Set `DB_MAX_CONNS: "10"` in `02-config.yaml`,
`make k8s-deploy`, scale to 10 replicas, and watch `/readyz` start failing with
`too many connections` while `/healthz` stays green. Fixes to try: lower `DB_MAX_CONNS`,
raise the instance tier, or put PgBouncer in front. This is the most common real-world
scaling wall for Go services on managed Postgres, and it is worth meeting it once
deliberately.

**Lose a spot node.** Google preempts spot VMs with ~30s notice. You can simulate it:
`gcloud compute instances delete <node-name> --zone=$ZONE`. Watch pods reschedule and the
node pool self-heal.

**Resource requests vs reality.** `make k8s-top` during load. The pods request 100m CPU;
if they are using 400m, the scheduler is packing them based on a fiction. Adjust requests
to what you observe, redeploy, and see how many pods fit per node change.

## Phase 6 — performance tests

Three k6 scripts, all taking `BASE_URL`:

| Script | Shape | Use it to |
| --- | --- | --- |
| `smoke.js` | 5 iterations, full CRUD lifecycle | Verify a deploy — fails on any bad check |
| `load.js` | Constant arrival rate, read-heavy mix | Measure latency at a fixed request rate |
| `stress.js` | Ramping arrival rate against `/burn` | Find the ceiling and drive the HPA |

```bash
# from your laptop (includes your home latency and uplink)
make loadtest-load BASE_URL=$(make -s k8s-url) RATE=100 DURATION=3m

# from inside the cluster (no internet in the path — the real server numbers)
make loadtest-cluster script=load.js RATE=200 DURATION=3m
```

Both `load.js` and `stress.js` use k6's **arrival-rate** executors on purpose. With a fixed
number of VUs, each VU waits for its response before sending the next one, so when the
server slows down the offered load silently drops and the graph flatters the service.
Arrival-rate holds the requested rate and queues, which is what you want when the question
is "how does the server behave at 200 rps".

What to compare, and what you will probably find:

1. **Laptop vs in-cluster** for the same RATE: the difference is your internet path. If
   p95 drops from 90ms to 6ms in-cluster, you were measuring Tallinn↔Finland, not the app.
2. **Cloud Run vs GKE** at the same rate: Cloud Run adds cold starts at the ramp but needs
   no capacity planning; GKE is steadier once warm. Fill in a table for yourself:
   p50/p95/p99, error rate, and euros per hour.
3. **Where the time actually goes.** `latency_list` vs `latency_create` in the k6 summary
   separate reads from writes. Then look at Cloud SQL → Query Insights: on a shared-core
   instance the database saturates long before the Go service does.
4. **Connection pool sizing.** Run the same test with `DB_MAX_CONNS` at 2, 5 and 10 with
   fixed replicas. Small pools queue in the app; large pools queue in Postgres. There is
   a sweet spot and it is lower than most people guess.
5. **Thresholds as SLOs.** `load.js` fails if p95 > 300ms or errors > 1%. Adjust these to
   what you consider acceptable and use the exit code — that is how a load test becomes a
   CI gate rather than a graph nobody reads.

Useful while measuring:

```bash
kubectl -n experiment-go get hpa -w                    # scaling decisions
make k8s-top                                          # actual CPU/memory per pod
make k8s-logs                                         # structured logs with durations
gcloud sql operations list --instance=experiment-pg    # database-side events
```

The app logs one JSON line per request including `duration` and `request_id`, so
Cloud Logging can answer "what were the slowest requests during the test":

```
resource.type="k8s_container"
jsonPayload.msg="request completed"
jsonPayload.duration > 500000000     # nanoseconds, i.e. slower than 500ms
```

## Teardown

```bash
make teardown-all      # app, Cloud Run, cluster, database — in that order
```

Then verify nothing is still billing:

```bash
gcloud container clusters list
gcloud sql instances list
gcloud run services list --region=$REGION
gcloud compute forwarding-rules list          # leftover load balancers
gcloud compute disks list                     # leftover PVC disks
```

The Artifact Registry repo survives on purpose (pennies, and it saves a rebuild next
time): `gcloud artifacts repositories delete containers --location=europe-north1`.

## Gotchas, collected

- **`exec format error` in pods** — an arm64 image on amd64 nodes. Use `make image-push`.
- **Pod stuck `CrashLoopBackOff` with `DATABASE_URL ... must be set`** — the config map or
  secret didn't apply; `kubectl -n experiment-go get cm,secret`.
- **Proxy sidecar logs `connection refused` / permission denied** — Workload Identity
  binding missing or wrong namespace/name: re-run `make gke-bind-sa`, and check
  `kubectl -n experiment-go describe sa experiment-go`.
- **Migration Job hangs at `Running`** — without `restartPolicy: Always` on the sidecar
  (native sidecar), the proxy never exits and the Job never completes. That's why the
  manifest declares it as an initContainer.
- **`too many connections`** — `DB_MAX_CONNS × replicas` exceeded the instance limit.
- **HPA shows `<unknown>` for CPU** — the metrics server needs a minute after cluster
  creation, and pods must declare CPU *requests* (they do).
- **LoadBalancer IP stays `<pending>`** — quota or the LB is still provisioning; give it
  two minutes, then `kubectl -n experiment-go describe svc experiment-go-lb`.
- **Cloud Run 503 right after deploy** — the revision failed to start; check `make run-logs`
  for the config error. The service fails fast on purpose rather than serving broken.
