# experiment-go

A Go REST microservice starter: [Gin](https://gin-gonic.com/) for HTTP, Go modules for
dependencies, pgx + [golang-migrate](https://github.com/golang-migrate/migrate) for
Postgres, structured logging with `log/slog`, graceful shutdown, and a Docker /
docker-compose setup driven entirely from the `Makefile`.

## Quick start

Everything runs in containers — you only need Docker and `make`.

```bash
make init   # creates .env from .env.example, downloads modules
make up     # builds the image, starts Postgres, runs migrations, starts the API
make smoke  # sanity-check the running endpoints
make logs   # follow API logs
make down   # stop the stack
```

The API is on <http://localhost:8080>.

Working on the code without rebuilding the image each time:

```bash
make up      # start the stack (Postgres is published on localhost:5432)
make run     # run the API on the host with text logs and debug level
```

## Endpoints

| Method | Path                 | Description                                   |
| ------ | -------------------- | --------------------------------------------- |
| GET    | `/healthz`           | Liveness — never touches the database         |
| GET    | `/readyz`            | Readiness — pings Postgres, 503 when it's out |
| GET    | `/api/v1/tasks`      | List tasks (`?limit=20&offset=0`)             |
| POST   | `/api/v1/tasks`      | Create a task                                 |
| GET    | `/api/v1/tasks/:id`  | Fetch one task                                |
| PUT    | `/api/v1/tasks/:id`  | Replace a task                                |
| DELETE | `/api/v1/tasks/:id`  | Delete a task                                 |

```bash
curl -s localhost:8080/api/v1/tasks \
  -H 'Content-Type: application/json' \
  -d '{"title":"ship the microservice"}'
```

Successful responses are wrapped in `{"data": ...}`, errors in `{"error": "..."}`.
Every response carries an `X-Request-ID` header (echoed from the request when present)
which also appears in the log line for that request.

## Layout

```
cmd/api/                  entrypoint: config, wiring, signal handling
internal/config/          environment-based configuration + validation
internal/logger/          slog setup (json|text, level from env)
internal/database/        pgx connection pool
internal/task/            example domain: model, Repository contract, Postgres impl
internal/httpapi/         router, middleware, handlers, http.Server lifecycle
migrations/               golang-migrate SQL files
```

`internal/task.Repository` is an interface, so the HTTP handlers are tested with a stub
and no database (`internal/httpapi/tasks_test.go`). Add a new resource by copying the
`task` package and registering its handlers in `internal/httpapi/router.go`.

## Make targets

Run `make` for the full list. The ones you'll use most:

| Target                        | What it does                                        |
| ----------------------------- | --------------------------------------------------- |
| `make init`                   | Create `.env`, download modules                     |
| `make up` / `make down`       | Start / stop the compose stack                      |
| `make restart`                | Rebuild and restart only the API container          |
| `make logs` / `make ps`       | Follow logs / show status                           |
| `make run`                    | Run the API on the host against the compose DB      |
| `make build`                  | Static binary into `bin/api`                        |
| `make test` / `make test-race`| Tests, with or without the race detector            |
| `make cover`                  | Coverage report (`coverage.html`)                   |
| `make lint` / `make lint-fix` | golangci-lint (installed into `bin/` on first use)  |
| `make check`                  | fmt-check + vet + lint + test — same as CI          |
| `make docker-build`           | Build the production image                          |
| `make migrate-up`             | Apply pending migrations                            |
| `make migrate-down`           | Roll back the last migration                        |
| `make migrate-new name=x`     | Create `migrations/00000N_x.{up,down}.sql`          |
| `make psql`                   | psql shell on the compose database                  |
| `make smoke`                  | curl the health and task endpoints                  |

## Configuration

All configuration comes from the environment (see `.env.example`). `make up` and
`make run` load `.env` automatically.

| Variable                 | Default       | Notes                                     |
| ------------------------ | ------------- | ----------------------------------------- |
| `APP_ENV`                | `development` | `production` puts Gin in release mode      |
| `HTTP_PORT`              | `8080`        |                                            |
| `HTTP_SHUTDOWN_TIMEOUT`  | `15s`         | Drain window for in-flight requests        |
| `LOG_LEVEL`              | `info`        | `debug` / `info` / `warn` / `error`        |
| `LOG_FORMAT`             | `json`        | `json` for prod, `text` for local reading  |
| `DATABASE_URL`           | —             | Full DSN; wins over the `POSTGRES_*` vars  |
| `POSTGRES_HOST/PORT/USER/PASSWORD/DB` | — | Used to compose the DSN               |
| `DB_MAX_CONNS`           | `10`          | pgx pool size                              |

The service fails fast on startup if the configuration is invalid or Postgres is
unreachable, so a bad deploy never reports itself as healthy.

## Docker

`Dockerfile` is a two-stage build: `golang:1.25-alpine` compiles a static,
`-trimpath`ed binary with the version stamped in via `-ldflags`, and the runtime stage
is Alpine with a non-root user (uid 10001), a `HEALTHCHECK` on `/healthz`, and nothing
else. Build it directly with:

```bash
make docker-build              # experiment-go:<git describe>
DOCKER_IMAGE=ghcr.io/pytsekas/experiment-go make docker-build docker-push
```

`docker-compose.yml` runs three services: `db` (Postgres 17 with a healthcheck and a
named volume), `migrate` (one-shot golang-migrate that must exit successfully), and
`api` (waits for both).

## Migrations

SQL pairs in `migrations/`, applied by golang-migrate through the compose `migrate`
service — no local tooling needed.

```bash
make migrate-new name=add_task_owner   # create the files, then edit them
make migrate-up                        # apply
make migrate-version                   # current version
make migrate-force version=1           # clear a dirty state after a failed migration
```

## CI

`.github/workflows/ci.yml` checks tidiness, formatting, `go vet`, golangci-lint and
race-enabled tests, then builds the Docker image with layer caching and asserts the
binary exits non-zero when required configuration is missing.
