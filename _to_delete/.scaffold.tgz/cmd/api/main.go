// Command api is the entrypoint of the experiment-go REST service.
package main

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"os/signal"
	"syscall"

	"github.com/pytsekas/experiment-go/internal/config"
	"github.com/pytsekas/experiment-go/internal/database"
	"github.com/pytsekas/experiment-go/internal/httpapi"
	"github.com/pytsekas/experiment-go/internal/logger"
	"github.com/pytsekas/experiment-go/internal/task"
)

// version is injected at build time: -ldflags "-X main.version=$(git describe)".
var version = "dev"

func main() {
	if err := run(); err != nil {
		// The logger may not exist yet, so fail loudly on stderr too.
		fmt.Fprintf(os.Stderr, "fatal: %v\n", err)
		os.Exit(1)
	}
}

func run() error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}

	log := logger.New(os.Stdout, cfg.Logger.Level, cfg.Logger.Format).With(
		slog.String("service", "experiment-go"),
		slog.String("version", version),
		slog.String("env", cfg.Env),
	)
	slog.SetDefault(log)

	// ctx is cancelled on SIGINT/SIGTERM, which starts graceful shutdown.
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	pool, err := database.NewPool(ctx, cfg.DB)
	if err != nil {
		return fmt.Errorf("database: %w", err)
	}
	defer pool.Close()

	log.Info("database connected", slog.Int("max_conns", cfg.DB.MaxConns))

	router := httpapi.NewRouter(httpapi.Deps{
		Logger:   log,
		Tasks:    task.NewPostgresRepository(pool),
		DB:       pool,
		Version:  version,
		Prodlike: cfg.IsProduction(),
	})

	srv := httpapi.NewServer(cfg.HTTP, router, log)
	if err := srv.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
		return fmt.Errorf("http server: %w", err)
	}

	return nil
}
